export interface Livro{
    nome: string;
    autor: string;
}
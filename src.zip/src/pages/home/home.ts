import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Livro } from '../../model/livro';
import { DestinoPage } from '../destino/destino';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  public livros: Livro [];

  constructor(public navCtrl: NavController) {

    this.livros = [
      {nome: "Java como programar", autor: "Deitel"},
      {nome: "Concrete Maths", autor: "Donald Knuth"},
      {nome: "C++ Como programar", autor:"Jheferson Kaique"}
    ];

    
  }

  vai (livro: Livro){

    this.navCtrl.push(DestinoPage, {livroSelecionado: livro});
  }

}
